def stepshift(ui):

    x = 0
    oi = ""

    while x < len(ui):
        ts = ord(ui[x]) + x

        oi = oi + chr(ts)

        x += 1

    return oi
